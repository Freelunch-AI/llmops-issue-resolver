__app_name__ = "llmops_issue-resolver"
__version__ = "0.1.0"